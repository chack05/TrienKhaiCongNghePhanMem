<?php
define("DB_HOST", 'host.docker.internal');
define("DB_USER", 'root');
define("DB_PASS", 'phamminhbien123');
define("DB_NAME", 'hkt_shop');
define("DB_PORT", '3307');
