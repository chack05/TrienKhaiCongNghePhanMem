<?php
include 'lib/session.php';
Session::destroy();